# Eclipse LLM Patch Bundle v0.1.1

Contains patched jars for:
- AssistAI plugin (`com.github.gradusnikov.eclipse.plugin.assistai.main_1.0.7.202603202120.jar`)
- Eclipse UI IDE (`org.eclipse.ui.ide_3.23.100.v20260327-1616.jar`)

## Install (macOS)

```bash
cd scripts
chmod +x install.sh rollback.sh
./install.sh
```

If Eclipse app path differs:

```bash
ECLIPSE_APP_PATH="/path/to/Eclipse.app" ./install.sh
```

After install, restart Eclipse with `-clean` once.
