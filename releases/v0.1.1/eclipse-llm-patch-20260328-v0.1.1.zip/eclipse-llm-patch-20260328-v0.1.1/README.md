# Eclipse LLM Patch Bundle v0.1.1

Contains patched jars for:
- AssistAI plugin (`com.github.gradusnikov.eclipse.plugin.assistai.main_1.0.7.202603202120.jar`)
- Eclipse UI IDE (`org.eclipse.ui.ide_3.23.100.v20260327-1616.jar`)

## Install (macOS)

```bash
cd scripts
chmod +x install.sh rollback.sh
./install.sh
```

If Eclipse app path differs:

```bash
ECLIPSE_APP_PATH="/path/to/Eclipse.app" ./install.sh
```

After install, restart Eclipse with `-clean` once.

## Install (Windows)

Open CMD in `scripts` and run:

```bat
install_windows.bat "C:\path\to\eclipse-ide" "C:\path\to\eclipse-llm-patch-20260328-v0.1.1"
```

Or set `ECLIPSE_HOME` and run without args:

```bat
set ECLIPSE_HOME=C:\path\to\eclipse-ide
install_windows.bat
```

After install, restart Eclipse with `-clean` once.
