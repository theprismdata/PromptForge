# Eclipse LLM Patch Bundle (2026-03-28)

This package installs patched Eclipse plugins for:
- AssistAI main plugin (`createProject` fallback fix, shell command tool)
- Eclipse IDE bundle (`project creation command support`)

## Included files

- `payload/assistai/plugins/com.github.gradusnikov.eclipse.plugin.assistai.main_1.0.7.202603202120.jar`
- `payload/llm-patch/plugins/org.eclipse.ui.ide_3.23.100.v20260327-1616.jar`
- `scripts/install.sh`
- `scripts/rollback.sh`

## Install (macOS)

1. Close Eclipse completely.
2. Run:

```bash
cd scripts
chmod +x install.sh rollback.sh
./install.sh
```

3. Start Eclipse once with `-clean`.

If Eclipse is not at `/Applications/Eclipse Java.app`, set:

```bash
ECLIPSE_APP_PATH="/path/to/Eclipse.app" ./install.sh
```

## Rollback

```bash
cd scripts
./rollback.sh
```

Or specify a backup directory:

```bash
./rollback.sh ~/.eclipse_llm_patch_backups/<timestamp>
```

## Notes

- Backups are stored under `~/.eclipse_llm_patch_backups/<timestamp>`.
- After install/rollback, restart Eclipse with `-clean` once.
