# Eclipse LLM 패치 번들 (2026-03-28)

이 패키지는 아래 패치된 Eclipse 플러그인을 설치합니다.
- AssistAI 메인 플러그인 (`createProject` 폴백 수정, 셸 명령 도구)
- Eclipse IDE 번들 (프로젝트 생성 명령 지원)

## 포함 파일

- `payload/assistai/plugins/com.github.gradusnikov.eclipse.plugin.assistai.main_1.0.7.202603202120.jar`
- `payload/llm-patch/plugins/org.eclipse.ui.ide_3.23.100.v20260327-1616.jar`
- `scripts/install.sh`
- `scripts/rollback.sh`

## 설치 (macOS)

1. Eclipse를 완전히 종료합니다.
2. 아래 명령을 실행합니다.

```bash
cd scripts
chmod +x install.sh rollback.sh
./install.sh
```

3. Eclipse를 `-clean` 옵션으로 1회 실행합니다.

Eclipse 경로가 `/Applications/Eclipse Java.app`가 아니라면:

```bash
ECLIPSE_APP_PATH="/path/to/Eclipse.app" ./install.sh
```

## 롤백

```bash
cd scripts
./rollback.sh
```

특정 백업 디렉터리를 지정하려면:

```bash
./rollback.sh ~/.eclipse_llm_patch_backups/<timestamp>
```

## 참고 사항

- 백업은 `~/.eclipse_llm_patch_backups/<timestamp>`에 저장됩니다.
- 설치/롤백 후에는 Eclipse를 `-clean` 옵션으로 1회 재시작하세요.
