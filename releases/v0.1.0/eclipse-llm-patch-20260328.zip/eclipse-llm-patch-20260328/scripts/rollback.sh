#!/usr/bin/env bash
set -euo pipefail

APP_PATH="${ECLIPSE_APP_PATH:-/Applications/Eclipse Java.app}"
ECLIPSE_DIR="${APP_PATH}/Contents/Eclipse"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_ROOT="${HOME}/.eclipse_llm_patch_backups"

if [[ ! -d "${ECLIPSE_DIR}" ]]; then
  echo "ERROR: Eclipse directory not found: ${ECLIPSE_DIR}"
  echo "Set ECLIPSE_APP_PATH if needed."
  exit 1
fi

if [[ $# -ge 1 ]]; then
  BACKUP_DIR="$1"
else
  BACKUP_DIR="$(ls -1dt "${BACKUP_ROOT}"/* 2>/dev/null | head -n 1 || true)"
fi

if [[ -z "${BACKUP_DIR:-}" || ! -d "${BACKUP_DIR}" ]]; then
  echo "ERROR: Backup directory not found."
  echo "Usage: ${SCRIPT_DIR}/rollback.sh <backup_dir>"
  exit 1
fi

restore_one() {
  local rel_dst="$1"
  local backup_file="${BACKUP_DIR}/${rel_dst}"
  local dst="${ECLIPSE_DIR}/${rel_dst}"
  local dst_dir
  dst_dir="$(dirname "${dst}")"

  if [[ ! -f "${backup_file}" ]]; then
    echo "Skip (no backup): ${backup_file}"
    return
  fi

  mkdir -p "${dst_dir}"
  cp "${backup_file}" "${dst}"
  echo "Restored: ${dst}"
}

restore_one "dropins/assistai/eclipse/plugins/com.github.gradusnikov.eclipse.plugin.assistai.main_1.0.7.202603202120.jar"
restore_one "dropins/llm-patch/eclipse/plugins/org.eclipse.ui.ide_3.23.100.v20260327-1616.jar"

echo ""
echo "Rollback complete from: ${BACKUP_DIR}"
echo "Restart Eclipse with -clean once."
