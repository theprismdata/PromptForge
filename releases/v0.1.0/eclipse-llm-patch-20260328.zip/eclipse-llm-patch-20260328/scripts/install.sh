#!/usr/bin/env bash
set -euo pipefail

APP_PATH="${ECLIPSE_APP_PATH:-/Applications/Eclipse Java.app}"
ECLIPSE_DIR="${APP_PATH}/Contents/Eclipse"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
BACKUP_ROOT="${HOME}/.eclipse_llm_patch_backups"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="${BACKUP_ROOT}/${STAMP}"

if [[ ! -d "${ECLIPSE_DIR}" ]]; then
  echo "ERROR: Eclipse directory not found: ${ECLIPSE_DIR}"
  echo "Set ECLIPSE_APP_PATH if needed."
  exit 1
fi

mkdir -p "${BACKUP_DIR}"

install_one() {
  local src="$1"
  local rel_dst="$2"
  local dst="${ECLIPSE_DIR}/${rel_dst}"
  local dst_dir
  dst_dir="$(dirname "${dst}")"
  local backup_target="${BACKUP_DIR}/${rel_dst}"
  local backup_dir
  backup_dir="$(dirname "${backup_target}")"

  if [[ ! -f "${src}" ]]; then
    echo "ERROR: Missing payload file: ${src}"
    exit 1
  fi

  mkdir -p "${dst_dir}" "${backup_dir}"
  if [[ -f "${dst}" ]]; then
    cp "${dst}" "${backup_target}"
    echo "Backed up: ${dst}"
  fi

  cp "${src}" "${dst}"
  echo "Installed: ${dst}"
}

install_one \
  "${PACKAGE_DIR}/payload/assistai/plugins/com.github.gradusnikov.eclipse.plugin.assistai.main_1.0.7.202603202120.jar" \
  "dropins/assistai/eclipse/plugins/com.github.gradusnikov.eclipse.plugin.assistai.main_1.0.7.202603202120.jar"

install_one \
  "${PACKAGE_DIR}/payload/llm-patch/plugins/org.eclipse.ui.ide_3.23.100.v20260327-1616.jar" \
  "dropins/llm-patch/eclipse/plugins/org.eclipse.ui.ide_3.23.100.v20260327-1616.jar"

cat > "${BACKUP_DIR}/restore_hint.txt" <<EOF
Rollback command:
  ${SCRIPT_DIR}/rollback.sh "${BACKUP_DIR}"
EOF

echo ""
echo "Install complete."
echo "Backup saved to: ${BACKUP_DIR}"
echo "Restart Eclipse with -clean once."
